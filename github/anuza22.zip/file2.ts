his.service.trendingMovieApiData().subscribe((result)=>{
      console.log(result,"trendingMovieData");
      this.trendingMovieResult = result.results;
    })
  }
  actionMovieData(){
    this.service.getActionMovieData().subscribe((result)=>{
      console.log(result,'actionMovieResult');
      this.actionMovieResult = result.results;
    })
  }
  adventureMovieData(){
    this.service.getAdventureMovieData().subscribe((result)=>{
      console.log(result,'adventureMovieResult');
      this.adventureMovieResult = result.results;
    })
  }
  comedyMovieData(){
    this.service.getComedyMovieData().subscribe((result)=>{
      console.log(result,'comdyMovieData');
      this.comedyMovieResult = result.results;
    })
  }
  animationMovieData(){
    this.service.getAnimationMovieData().subscribe((result)=>{
      console.log(result,'animationMovieData');
      this.animationMovieResult = result.results;
    })
  }
  documentaryMovieData(){
    this.service.getDocumentaryMovieData().subscribe((result)=>{
      console.log(result,'documentaryMovieData');
      this.documentaryMovieResult = result.results;
    })
  }
  
  

} <div class="contain mt-5 p-5">
  <form [formGroup]="searchForm" (ngSubmit)="submitForm()">
    <div class="row">
      <div class="mb-3 col-lg-10">
        <input type="text" class="form-control" formControlName="movieName" placeholder="Search movie">
      </div>
      <div class="col-lg-2">
        <button class="btn btn-md">SEARCH</button>
      </div>
    </div>
    
  </form>
  <div class="row mt-5">
    <div class="col-lg-4" *ngFor="let s of searchResult">
      <div class="row">
        <div class="col-lg-3 mt-4 mb-4" *ngIf="s.poster_path">
          <img src="https://image.tmdb.org/t/p/original/{{s.poster_path}}"
          [routerLink]="['/movie',s.id]" >

        </div>
        <div class="col-lg-9 mt-4 mb-4">
          <h5>{{s.original_title}}</h5>
          <!-- <p>{{s.overview}}</p> -->
        </div>
      </div>
    </div>

  </div>
</div> import { Component } from '@angular/core';
import {FormControl,FormGroup} from '@angular/forms';
import { MovieApiServiceService } from 'src/app/service/movie-api-service.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent {
  constructor(private service:MovieApiServiceService){}

  searchResult:any;

searchForm = new FormGroup(
  {
    'movieName':new FormControl(null)
  }
);
submitForm(){
  console.log(this.searchForm.value,'searchform');
  this.service.getSearchMovie(this.searchForm.value).subscribe((result)=>{
    console.log(result,"searchmoVIEEE");
    this.searchResult = result.results;
  })
}

} import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MovieApiServiceService {

  constructor(private http:HttpClient) {}
    baseurl="https://api.themoviedb.org/3";
    apiKey='1dd2f814fe601c6c852707474595e23f';
    // bannerApiData
    bannerApiData():Observable<any>{
      return this.http.get(`${this.baseurl}/trending/all/week?api_key=${this.apiKey}`)
    }
    //trendingMovieApiData
    trendingMovieApiData():Observable<any>{
      return this.http.get(`${this.baseurl}/trending/movie/day?api_key=${this.apiKey}`)
    }
    getSearchMovie(data:any):Observable<any>{
      return this.http.get(`${this.baseurl}/search/movie?api_key=${this.apiKey}&query=${data.movieName}`)
    }
    getMovieDetails(data:any):Observable<any>{
      return this.http.get(`${this.baseurl}/movie/${data}?api_key=${this.apiKey}`)

    }
    getMovieVideo(data:any):Observable<any>{
      return this.http.get(`${this.baseurl}/movie/${data}/videos?api_key=${this.apiKey}`)

    }
    getMovieCast(data:any):Observable<any>{
      return this.http.get(`${this.baseurl}/movie/${data}/credits?api_key=${this.apiKey}`)

    }
    //action movie
    getActionMovieData():Observable<any>{
      return this.http.get(`${this.baseurl}/discover/movie?api_key=${this.apiKey}&with_genres=28`)
    }
    //adventure movie
    getAdventureMovieData():Observable<any>{
      return this.http.get(`${this.baseurl}/discover/movie?api_key=${this.apiKey}&with_genres=12`)
    }
    //animation movie
    getAnimationMovieData():Observable<any>{
      return this.http.get(`${this.baseurl}/discover/movie?api_key=${this.apiKey}&with_genres=16`)
    }
    //comedy movie
    getComedyMovieData():Observable<any>{
      return this.http.get(`${this.baseurl}/discover/movie?api_key=${this.apiKey}&with_genres=35`)
    }
    //documentary
    getDocumentaryMovieData():Observable<any>{
      return this.http.get(`${this.baseurl}/discover/movie?api_key=${this.apiKey}&with_genres=99`)
    }

  
}