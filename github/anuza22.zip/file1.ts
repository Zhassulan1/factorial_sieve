<!-- banner start -->

<div class="contain-fluid">
  <div id="carouselExampleDark" class="carousel carousel-dark slide">
    
    <div class="carousel-inner">
      <div class="carousel-item active"
       data-bs-interval="10000"
        *ngFor="let item of bannerResult;let i=index"
        [ngClass]="{active:i===0}">
        <img src="https://image.tmdb.org/t/p/original/{{item.backdrop_path}}" class="d-block w-100" alt="...">
        <div class="carousel-caption d-none d-md-block">
          <h2>{{item.original_title}}</h2>
          <p>{{item.overview}}</p>
        </div>
      </div>
      
     
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>
</div>


<!-- banner end -->

<div class="contain mt-3 p-4 ">
  <!-- trending movies -->
  <div class="row ">
    <h5 class="text-white">Trending Movies</h5>
    <div class="rowposter">
      <ng-container *ngFor="let t of trendingMovieResult">
        <img src="https://image.tmdb.org/t/p/original/{{t.poster_path}}" 
      class="rowimg largeposter"
       alt="..."
       [routerLink]="['/movie',t.id]"
       >

      </ng-container>
      
    </div>
  </div>

    <!-- action movies -->
    <div class="row mt-4">
      <h5 class="text-white">Action Movies</h5>
      <div class="rowposter mt-3 p-2">
        <ng-container *ngFor="let a of actionMovieResult">
          <img src="https://image.tmdb.org/t/p/original/{{a.poster_path}}" 
        class="rowimg largeposter"
         alt="..."
         [routerLink]="['/movie',a.id]"
         >
  
        </ng-container>
        
      </div>
    </div>

     <!-- adventure movies -->
     <div class="row mt-4">
      <h5 class="text-white">Adventure Movies</h5>
      <div class="rowposter mt-3 p-2">
        <ng-container *ngFor="let ad of adventureMovieResult">
          <img src="https://image.tmdb.org/t/p/original/{{ad.poster_path}}" 
        class="rowimg largeposter"
         alt="..."
         [routerLink]="['/movie',ad.id]"
         >
  
        </ng-container>
        
      </div>
    </div>

     <!-- comedy movies -->
     <div class="row mt-4">
      <h5 class="text-white">Comedy Movies</h5>
      <div class="rowposter mt-3 p-2">
        <ng-container *ngFor="let c of comedyMovieResult">
          <img src="https://image.tmdb.org/t/p/original/{{c.poster_path}}" 
        class="rowimg largeposter"
         alt="..."
         [routerLink]="['/movie',c.id]"
         >
  
        </ng-container>
        
      </div>
    </div>
     <!-- documentary movies -->
     <div class="row mt-4">
      <h5 class="text-white">Documentary Movies</h5>
      <div class="rowposter mt-3 p-2">
        <ng-container *ngFor="let d of documentaryMovieResult">
          <img src="https://image.tmdb.org/t/p/original/{{d.poster_path}}" 
        class="rowimg largeposter"
         alt="..."
         [routerLink]="['/movie',d.id]"
         >
  
        </ng-container>
        
      </div>
    </div>
     <!-- animation movies -->
     <div class="row mt-4">
      <h5 class="text-white">Animation Movies</h5>
      <div class="rowposter mt-3 p-2">
        <ng-container *ngFor="let an of animationMovieResult">
          <img src="https://image.tmdb.org/t/p/original/{{an.poster_path}}" 
        class="rowimg largeposter"
         alt="..."
         [routerLink]="['/movie',an.id]"
         >
  
        </ng-container>
        
      </div>
    </div>
</div> import { Component } from '@angular/core';
import { MovieApiServiceService } from 'src/app/service/movie-api-service.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent{
  constructor(private service:MovieApiServiceService){}
  bannerResult:any=[];
  trendingMovieResult:any=[];
  actionMovieResult:any=[];
  adventureMovieResult:any=[];
  animationMovieResult:any=[];
  comedyMovieResult:any=[];
  documentaryMovieResult:any=[];

  ngOnInit(): void {
    this.bannerData();
    this.trendingMovieData();
    this.actionMovieData();
    this.adventureMovieData();
    this.comedyMovieData();
    this.animationMovieData();
    this.documentaryMovieData();
  }
  bannerData(){
   this.service.bannerApiData().subscribe((result)=>{
    console.log(result,"bannerResult");
    this.bannerResult = result.results;
   })
  }
  trendingMovieData(){
    t