from dotenv import load_dotenv
load_dotenv() import os
aws_secret_access_key = os.getenv('AWS_SECRET_ACCESS_KEY')
print(aws_secret_access_key) def generate_key(filename):
    return f"{uuid.uuid4()}_{filename}" def upload_bytes(bucket_name, key, bytes_data):
    s3_client = boto3.client('s3')
    s3_client.put_object(Bucket=bucket_name, Key=key, Body=bytes_data)
    return f"https://{bucket_name}.s3.amazonaws.com/{key}" def upload_file(bucket_name, key, file_path):
    s3_client = boto3.client('s3')
    s3_client.upload_file(file_path, bucket_name, key)
    return f"https://{bucket_name}.s3.amazonaws.com/{key}" from django.urls import path
from . import views

urlpatterns =